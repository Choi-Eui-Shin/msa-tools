#!/bin/bash

echo "@.@"
echo "@.@ Build Application..." 
docker rmi -f dreamsalmon/was-ehcache:latest
docker build -f Dockerfile -t dreamsalmon/was-ehcache .
docker push dreamsalmon/was-ehcache