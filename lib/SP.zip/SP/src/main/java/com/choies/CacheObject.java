package com.choies;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CacheObject implements Serializable
{
	private String fieldName;
	private String fieldValue;
}
