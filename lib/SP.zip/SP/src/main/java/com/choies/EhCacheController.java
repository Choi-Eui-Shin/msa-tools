package com.choies;

import java.net.InetAddress;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * @author 최의신 (choies@kr.ibm.com)
 *
 */
@Controller
public class EhCacheController {
	@Autowired
	private CacheManager cacheManager;

	/**
	 * @param name
	 * @param value
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/put/{name}/{value}", method = RequestMethod.GET)
	public String put(@PathVariable String name, @PathVariable String value, ModelMap model, HttpServletRequest request)
	{
		Cache cache = cacheManager.getCache("CHOIES");
		Element em = new Element(name, value);
		cache.put(em);

		model.addAttribute("server", getServer());
		model.addAttribute("message", "SUCCESS");

		return "result";
	}
	
	/**
	 * @param name
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/get/{name}", method = RequestMethod.GET)
	public String put(@PathVariable String name, ModelMap model, HttpServletRequest request)
	{
		Cache cache = cacheManager.getCache("CHOIES");
		Element em = cache.get(name);
		if ( em != null )
			model.addAttribute("message", "Value = " + em.getObjectValue());
		else
			model.addAttribute("message", "NOT FOUND");
		
		model.addAttribute("server", getServer());
		
		return "result";
	}
	
	private String getServer() {
		String host = null;
		try {
			InetAddress ip = InetAddress.getLocalHost();
			host = ip.getHostAddress();
		}catch(Exception e) {}
		
		return host;
	}
}
