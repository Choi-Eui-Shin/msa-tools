package com.choies;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author 최의신 (choies@kr.ibm.com)
 *
 */
@Controller
public class NavigatorController
{
	@RequestMapping(value = "/form/{screenId}", method = RequestMethod.GET)
	public String gotoPage(@PathVariable String screenId, ModelMap model) {
		return screenId;
	}
}
