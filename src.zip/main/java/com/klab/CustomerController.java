package com.klab;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klab.vo.LoginVO;
import com.klab.vo.ResultVO;
import com.klab.vo.UserVO;

@RestController
@RequestMapping("/DEV/customer")
public class CustomerController {

	@PostMapping("/v1/login")
	public ResultVO v1Login(@RequestBody LoginVO login)
	{
		System.out.println("@.@ " + login);
		
		UserVO payload = UserVO.builder()
							.userId(login.getUserId())
							.userName("왕지현")
							.userPoint(1000)
							.mobileNo("010-49**-6**2")
							.email("ccc@**.ibm.com")
							.postNo("07326")
							.address("서울특별시 영등포구 국제금융로 10")
							.addressDetail("Three IFC")
							.jwt("1234ABC")
							.build();
		
		ResultVO result = ResultVO.builder()
							.returnCode(true)
							.result(payload)
							.build();
		
		return result;
	}
	


}
