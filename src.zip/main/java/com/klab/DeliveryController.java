package com.klab;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klab.vo.DeliveryVO;
import com.klab.vo.ResultVO;

@RestController
@RequestMapping("/DEV/delivery")
public class DeliveryController
{
	int count = 1;
	
	@GetMapping("/v1/inquiryHistory")
	public ResultVO inquiryHistory()
	{
		List<DeliveryVO> payload = new ArrayList<DeliveryVO>();
		
		DeliveryVO hist = DeliveryVO.builder()
				.shippingId("202005KL1")
				.orderId("12344")
				.userId("ccc@ibm")
				.userName("왕지현")
				.productName("KF94")
				.productOption("대형")
				.qty(2)
				.amount(3000)
				.shippingState("배송중")
				.build();

			payload.add(hist);
			
			hist = DeliveryVO.builder()
				.shippingId("202005KL1")
				.orderId("12344")
				.userId("ccc@ibm")
				.userName("왕지현")
				.productName("KF94")
				.productOption("대형")
				.qty(2)
				.amount(3000)
				.shippingState("배송중" + (count++))
				.build();
			
			payload.add(hist);

		ResultVO result = ResultVO.builder()
							.returnCode(true)
							.result(payload)
							.build();
		
		return result;
	}
	
	/**
	 * @param shipId
	 * @param state
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/v1/modifyState/{shipId}/{state}")
	public ResultVO modifyState(@PathVariable String shipId, @PathVariable String state)
	{
		Map payload = new HashMap<>();
		payload.put("shippingState", state);

		ResultVO result = ResultVO.builder()
							.returnCode(true)
							.result(payload)
							.build();
		
		return result;
	}


}
