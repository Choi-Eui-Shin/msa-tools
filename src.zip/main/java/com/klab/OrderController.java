package com.klab;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klab.vo.OrderRequestVO;
import com.klab.vo.OrderResultVO;
import com.klab.vo.ResultVO;

@RestController
@RequestMapping("/DEV/order")
public class OrderController {

	@PostMapping("/v1/order")
	public ResultVO inquery(@RequestBody OrderRequestVO orderInfo)
	{
		OrderResultVO payload = OrderResultVO.builder()
									.orderId("1234")
									.orderQty(3)
									.payAmount(4500)
									.orderDate("2020.05.20")
									.build();
		
		ResultVO result = ResultVO.builder()
							.returnCode(true)
							.result(payload)
							.build();
		
		return result;
	}
	

}
