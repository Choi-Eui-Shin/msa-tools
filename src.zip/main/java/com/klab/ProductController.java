package com.klab;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klab.util.Utils;
import com.klab.vo.ProductInqueryVO;
import com.klab.vo.ProductVO;
import com.klab.vo.ResultVO;

@RestController
@RequestMapping("/DEV/product")
public class ProductController {

	@PostMapping("/v1/inquiry")
	public ResultVO inquiry(@RequestBody ProductInqueryVO productId)
	{
		List<ProductVO> payload = new ArrayList<ProductVO>();
		
		ProductVO prod = ProductVO.builder()
							.productId("4b6c9e02-42d3-4d2b-83d8-b2414db5730e")
							.productShortId("KF941903")
							.productName("KF94 마스크")
							.productOption("(20개)")
							.price(1500)
							.inventoryCount(1000)
							.productImage(Utils.convertImage2Base64("u321.jpg"))
							.productSmallImage(Utils.convertImage2Base64("u101.png"))
							.build();
		payload.add(prod);
		
		ResultVO result = ResultVO.builder()
							.returnCode(true)
							.result(payload)
							.build();
		
		return result;
	}
	

}
