package com.klab.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.klab.vo.ProductVO;

public class MakeProduct {

	public static void main(String[] args) throws Exception
	{
		ProductVO prod = ProductVO.builder()
				.productId("4b6c9e02-42d3-4d2b-83d8-b2414db5730e")
				.productShortId("KF941903")
				.productName("KF94 마스크")
				.productBundle("(20개)")
				.productOption("대형")
				.price(1500)
				.inventoryCount(1000)
				.productImage(Utils.convertImage2Base64("u321.jpg"))
				.productSmallImage(Utils.convertImage2Base64("u101.png"))
				.build();

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		System.out.println(gson.toJson(prod));
	}

}
