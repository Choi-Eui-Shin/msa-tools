package com.klab.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.util.Base64;
import java.util.UUID;

import org.springframework.core.io.ClassPathResource;

public class Utils
{
	/**
	 * @param t
	 * @return
	 */
	public static String getStackTrace(Throwable t) {
		StringWriter sw = new StringWriter();
		t.printStackTrace(new PrintWriter(sw));
		return sw.toString();
	}

	/**
	 * @param imageFile
	 * @return
	 */
	public static String convertImage2Base64(String imageFile)
	{
		 FileInputStream inputStream = null;
         ByteArrayOutputStream byteOutStream = null;
         String encString = "";
         try
         {
//        	 ClassPathResource res = new ClassPathResource(imageFile);    
//        	 File file = new File(res.getPath());
        	 
        	 //File file = new File(Utils.class.getResource(imageFile).getFile());
        	 
        	 File file = new File(imageFile);
        	 
             inputStream = new FileInputStream( file );
             byteOutStream = new ByteArrayOutputStream();

             int len = 0;
             byte[] buf = new byte[1024];
             while( (len = inputStream.read( buf )) != -1 ) {
                 byteOutStream.write(buf, 0, len);
             }

             byte[] fileArray = byteOutStream.toByteArray();
             encString = "data:image/" + getExt(imageFile) + ";base64," + new String(Base64.getEncoder().encode(fileArray));
         } catch(Exception e) {
             e.printStackTrace();
         } finally {
        	 try {
	             inputStream.close();
	             byteOutStream.close();
        	 }catch(Exception e) {}
         }
         
         return encString;
	}
	
	/**
	 * @return
	 */
	public static String shortUUID()
	{
		UUID uuid = UUID.randomUUID();
		long l = ByteBuffer.wrap(uuid.toString().getBytes()).getLong();
		return Long.toString(l, Character.MAX_RADIX);
	}

	/**
	 * @return
	 */
	public static String getUUID()
	{
		return UUID.randomUUID().toString();
	}	
	
	/**
	 * @param file
	 * @return
	 */
	public static String getExt(String file)
	{
		int ix = file.lastIndexOf(".");
		if ( ix != -1 )
			return file.substring(ix+1);
		else
			return file;
	}
	
	/**
	 * @param path
	 * @return
	 */
	public static String getFilename(String path)
	{
		int ix = path.lastIndexOf("\\");
		if ( ix != -1 )
			return path.substring(ix+1);
		
		ix = path.lastIndexOf("/");
		if ( ix != -1 )
			return path.substring(ix+1);
		
		return path;
	}
}
