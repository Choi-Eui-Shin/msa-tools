package com.klab.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class DeliveryVO
{
	private String shippingId;
	private String orderId;
	private String userId;
	private String userName;
	private String orderDate;
	private String productName;
	private String productOption;
	private int qty;
	private long amount;
	private String shippingState;
}
