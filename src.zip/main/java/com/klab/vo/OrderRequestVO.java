package com.klab.vo;

import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class OrderRequestVO {
	private String userId;
	private String userPoint;
	private String postNo;
	private String address;
	private String addressDetail;
	private String payAmount;
	private List<ProductVO> products;
}
