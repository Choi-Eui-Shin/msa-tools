package com.klab.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class OrderResultVO {
	private String orderId;
	private String orderDate;
	private int orderQty;
	private long payAmount;
}
