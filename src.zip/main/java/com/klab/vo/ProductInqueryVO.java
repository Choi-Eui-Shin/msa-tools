package com.klab.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class ProductInqueryVO {
	private String [] productId;
}
