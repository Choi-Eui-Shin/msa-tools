package com.klab.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * @author 최의신 (choies@kr.ibm.com)
 *
 */
@Setter
@Getter
@Builder
public class ProductVO {
	private String productId;
	private String productName;
	private String productBundle;
	private String productOption;
	private long price;
	private long inventoryCount;
	private String productImageUrl;
	private String productImage;
	private String productSmallImage;
	private String productShortId;
	private long usePoint;
	private int qty;
}
