package com.klab.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class ResultVO {
	private boolean returnCode;
	private String message;
	private Object result;
}
