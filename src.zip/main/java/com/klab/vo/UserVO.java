package com.klab.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class UserVO {
	private String userId;
	private long userPoint;
	private String userName;
	private String mobileNo;
	private String email;
	private String postNo;
	private String address;
	private String addressDetail;
	private String jwt;
}
